# Chapter Performance Dashboard API

A robust REST API for managing chapter performance data with features like caching, rate limiting, and bulk operations.

## Features

- 🔐 User and Admin Authentication
- 📊 Chapter Performance Management
- 🚀 Bulk Upload Support
- 💾 Redis Caching
- ⚡ Rate Limiting
- 📝 Comprehensive API Documentation

## Tech Stack

- Node.js & Express.js
- MongoDB (Database)
- Redis (Caching & Rate Limiting)
- PM2 (Process Management)

## Prerequisites

- Node.js 18+
- MongoDB
- Redis
- Postman (for testing APIs)

## Installation & Setup

1. **Clone the repository**

```bash
git clone <repository-url>
cd mathongo-backend
```

2. **Install dependencies**

```bash
npm install
```

3. **Environment Variables**
   Create a `.env` file in the root directory:

```env
NODE_ENV=development
PORT=3000
MONGODB_URI=your_mongodb_uri
REDIS_URL=redis://localhost:6379
ADMIN_API_KEY=mathongo_admin_2024_secure_key
ADMIN_SETUP_KEY=suraj123
```

4. **Start the server**

```bash
# Development
npm run dev

# Production
npm start
```

## Postman Collection Setup

1. Import the `mathongo-chapter-dashboard.postman_collection.json` file into Postman
2. Set up environment variables in Postman:
   - `base_url`: Your API base URL (e.g., http://localhost:3000)
   - `admin_api_key`: Your admin API key
   - `admin_setup_key`: Your admin setup key
   - `jwt_token`: Will be automatically set after login
   - `created_chapter_id`: Will be automatically set after creating/fetching a chapter

### Running the Collection

1. **Authentication Flow**:

   - Run "Register User" to create a new user
   - Run "Setup Admin" to create an admin account
   - Run "Login User" to get JWT token

2. **Chapter Management Flow**:
   - Use "Get All Chapters" to list chapters (this will automatically set `created_chapter_id`)
   - Use "Get Chapter by ID" to view specific chapter (uses `created_chapter_id`)
   - Use "Upload Chapters (Bulk)" to import multiple chapters

### Important Notes for File Upload

1. Prepare your `mock-chapters.json` file with chapter data
2. In Postman's "Upload Chapters (Bulk)" request:
   - Select form-data
   - Add key "file" (type: File)
   - Select your mock-chapters.json file
   - Ensure admin_api_key is set in headers

## API Flow & Rate Limits

1. **Authentication**

   - Register/Login endpoints: 5 requests/minute
   - Admin setup: 3 requests/15 minutes

2. **Chapter Management**

   - GET requests: 30 requests/minute
   - Bulk upload: 5 requests/15 minutes
   - Cache duration: 1 hour for GET requests

3. **Rate Limit Reset**
   - Use "Reset Rate Limits" endpoint (admin only)
   - 900-second cooldown on rate limit exceeded

## Error Handling

The API uses standard HTTP status codes:

- 200: Success
- 400: Bad Request
- 401: Unauthorized
- 403: Forbidden
- 429: Too Many Requests
- 500: Server Error

## Monitoring & Logs

- Use PM2 for process management
- Access logs via `pm2 logs`
- Monitor metrics with `pm2 monit`

## Production Deployment

1. Set up environment variables
2. Install PM2 globally: `npm install -g pm2`
3. Start with PM2: `pm2 start ecosystem.config.js`
4. Save PM2 process list: `pm2 save`
5. Setup PM2 startup script: `pm2 startup`

## Support

For any queries or support, please contact the development team.

## License

This project is licensed under the MIT License.
